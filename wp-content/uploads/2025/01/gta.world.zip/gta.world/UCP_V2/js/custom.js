/* Add here all your JS customizations */

$(function () {

  $(document).on("click", ".modal-submit", function (c) {
    c.preventDefault(), $.magnificPopup.close()
  });

  // Maintain Scroll Position
  if (typeof localStorage !== 'undefined') {
    if (localStorage.getItem('sidebar-left-position') !== null) {
      var initialPosition = localStorage.getItem('sidebar-left-position'),
        sidebarLeft = document.querySelector('#sidebar-left .nano-content');

      sidebarLeft.scrollTop = initialPosition;
    }
  }

  $(document).on('click', 'a:not([href="#"]):not([id]).nav-link', function (e) {
    //NProgress.start();
    $('#innercontent_loader').show();
  });

  /*
    Set blue line automatically under navigation bars
  */

  $('a[name="modelnav"].active').each(function (key) {
    var $this = $(this);
    var offset = $this.position();
    var width = $this.css('width');
    var height = $this.height();

    $('.yellow-bar').css('position', 'inherit');
    $('.yellow-bar').css('left', offset.left);
    $('.yellow-bar').css('top', offset.top);
    $('.yellow-bar').css('right', offset.right);
    $('.yellow-bar').css('width', width);
  });

  $(document).on('click', 'a[name="modelnav"]', function (e) {

    var $this = $(this);
    var offset = $this.position();
    var width = $this.css('width');
    var height = $this.height();

    $('.yellow-bar').css('position', 'inherit');
    $('.yellow-bar').css('left', offset.left);
    $('.yellow-bar').css('top', offset.top);
    $('.yellow-bar').css('right', offset.right);
    $('.yellow-bar').css('width', width);

    /*var leftValue = ($(this).css('width')).replace('px', ''); // Width of current selection // 110.77
    $navItem = $(this); // Selected item

    $prevItems = $navItem.prevAll('a[name="modelnav"]'); // Get all previous siblings //
    $prevItems.each(function(key) {
      var width = ($(this).css('width')).replace('px', ''); // Get width of current sibling // 110.77
      leftValue = leftValue + width; // Add the sibling's width to the final left value. // 220
    });
    $('.yellow-bar').css('width', $navItem.css('width')); // Set the width of the yellow bar to the width of the selected item. // 110
    $('.yellow-bar').css('left', leftValue + 'px'); // Set the final left value // 220*/
  });

  /*
    Ripple effects
  */
  const Color = function () {
    const regRGB = /rgb\((\d+),(\d+),(\d+)\)/i;
    const regRGBA = /rgba\((\d+),(\d+),(\d+),(1|0(?:.\d+)?)\)/i;
    const regHSL = /hsl\((\d+),(\d+)\%,(\d+)\%\)/i;
    const regHSLA = /hsla\((\d+),(\d+)%,(\d+)%,(1|0(?:.[\d+])?)\)/i;
    const regHEX3 = /^#([A-F0-9])([A-F0-9])([A-F0-9])$/i;
    const regHEX6 = /^#([A-F0-9]{2,2})([A-F0-9]{2,2})([A-F0-9]{2,2})$/i;

    const colorCheck = [
      {
        regex: regHEX3,
        constructor: "fromHEX"
      },
      {
        regex: regHEX6,
        constructor: "fromHEX"
      },
      {
        regex: regRGB,
        constructor: "fromRGBA"
      },
      {
        regex: regRGBA,
        constructor: "fromRGBA"
      },
      {
        regex: regHSL,
        constructor: "fromHSLA"
      },
      {
        regex: regHSLA,
        constructor: "fromHSLA"
      }
    ];


    const between = function between(val, min, max) {
      return Math.min(Math.max(val, max), min);
    };

    const toHSL = function toHSL(r, g, b) {
      r /= 255;
      g /= 255;
      b /= 255;
      var cMax = Math.max(r, g, b);
      var cMin = Math.min(r, g, b);
      var delta = cMax - cMin;
      this.l = (cMax + cMin) / 2;
      if (delta == 0) {
        this.h = 0;
        this.s = 0;
      } else {
        this.s = delta / (1 - Math.abs(2 * this.l - 1));
        if (cMax === r) {
          this.h = 60 * ((g - b) / delta % 6);
        } else if (cMax === g) {
          this.h = 60 * ((b - r) / delta + 2);
        } else {
          this.h = 60 * ((r - g) / delta + 4);
        }
      }
    };
    const toRGB = function toRGB(h, s, l) {
      var c = (1 - Math.abs(2 * l - 1)) * s,
        x = c * (1 - Math.abs(h / 60 % 2 - 1)),
        m = l - c / 2;
      var out = [0, 0, 0];
      switch (Math.floor(h / 60)) {
        case 0:
          out = [c, x, 0];
          break;
        case 1:
          out = [x, c, 0];
          break;
        case 2:
          out = [0, c, x];
          break;
        case 3:
          out = [0, x, c];
          break;
        case 4:
          out = [x, 0, c];
          break;
        case 5:
          out = [c, 0, x];
          break;
      }

      return out.map(x => Math.round((x + m) * 255));
    };

    const fromHTMLColor = function fromHTMLColor() {
      let testCanvas = document.createElement("canvas");
      if (testCanvas.getContext) {

        let testCTX = testCanvas.getContext('2d');
        testCanvas.width = testCanvas.height = 1;
        return function (name) {
          testCTX.fillStyle = name;
          testCTX.fillRect(0, 0, 1, 1);
          let cv = testCTX.getImageData(0, 0, 1, 1).data;
          return `rgba(${cv[0]},${cv[1]},${cv[2]},${cv[3] / 255})`;
        };
      }
      return function () {
        // display warning, return null
        console.warn(
          "Canvases aren't supported in your browser. Cannot convert web colors");

        return null;
      };
    }();

    const Color = function (str) {
      if (!(this instanceof Color)) {
        return new Color(str);
      }
      this.init(str);
    };

    Color.prototype = {
      init(str) {
        str = str.replace(/\s/gi, "");
        for (var cc = 0, clen = colorCheck.length; cc < clen; cc++) {
          var match = str.match(colorCheck[cc].regex);
          if (!match) continue;
          match.shift();
          match[3] = match[3] || 1;
          return this[colorCheck[cc].constructor].apply(this, match);
        }
        // try webColor if supported
        let webColor = this.fromHTMLColor(str);
        if (webColor) {
          return webColor;
        }
        this.h = 0;
        this.s = 0;
        this.l = 0;
        this.a = 0;
        throw "Error: Unrecognised Color Format";
      },
      fromRGBA(r, g, b, a) {
        this.r = between(parseInt(r), 255, 0);
        this.g = between(parseInt(g), 255, 0);
        this.b = between(parseInt(b), 255, 0);
        this.a = between(parseFloat(a), 1, 0);
      },
      fromHSLA(h, s, l, a) {
        this.h = parseInt(h) % 360;
        this.s = between(parseInt(s), 100, 0) / 100;
        this.l = between(parseInt(l), 100, 0) / 100;
        this.a = between(parseFloat(a), 1, 0);
      },
      fromHEX(r, g, b) {
        this.r = parseInt((r + r).substr(-2), 16);
        this.g = parseInt((g + g).substr(-2), 16);
        this.b = parseInt((b + b).substr(-2), 16);
        this.a = 1;
      },
      fromHTMLColor(name) {
        let color = fromHTMLColor(name);
        if (color) {
          this.init(color);
          return true;
        }
        return false;
      },
      toHSLString() {
        return `hsl(${this.h}, ${this.s * 100}%, ${this.l * 100}%)`;
      },
      toHSLAString() {
        return `hsla(${this.h}, ${this.s * 100}%, ${this.l * 100}%, ${this.a})`;
      },
      toRGBString() {
        return `rgb(${this.r}, ${this.g}, ${this.b})`;
      },
      toRGBAString() {
        return `rgba(${this.r}, ${this.g}, ${this.b}, ${this.a})`;
      },
      toHexString() {
        return `#${this.r.toString(16)}${this.g.toString(16)}${this.b.toString(16)}`;
      },
      lerp(fromColor, toColor, t, mt = 1) {
        t = Math.min(t, mt) / mt;
        this.r = (1 - t) * fromColor.r + t * toColor.r;
        this.g = (1 - t) * fromColor.g + t * toColor.g;
        this.b = (1 - t) * fromColor.b + t * toColor.b;
        this.a = (1 - t) * fromColor.a + t * toColor.a;
      }
    };


    Object.defineProperty(Color.prototype, "r", {
      set(r) {
        r = r || 0;
        var g = this.g || 0;
        var b = this.b || 0;
        toHSL.apply(this, [r, g, b]);
      },
      get() {
        var h = this.h,
          s = this.s,
          l = this.l;
        return toRGB(h, s, l)[0];
      }
    });


    Object.defineProperty(Color.prototype, "g", {
      set(g) {
        var r = this.r || 0;
        g = g || 0;
        var b = this.b || 0;
        toHSL.apply(this, [r, g, b]);
      },
      get() {
        var h = this.h,
          s = this.s,
          l = this.l;
        return toRGB(h, s, l)[1];
      }
    });


    Object.defineProperty(Color.prototype, "b", {
      set(b) {
        var r = this.r || 0;
        var g = this.g || 0;
        b = b || 0;
        toHSL.apply(this, [r, g, b]);
      },
      get() {
        var h = this.h,
          s = this.s,
          l = this.l;
        return toRGB(h, s, l)[2];
      }
    });
    return Color;
  }();
  ;
  const Ripple = function () {
    // create a cross-browser function for getting the next frame
    window.requestAnimFrame = function () {
      return (
        window.requestAnimFrame ||
        window.requestAnimationFrame ||
        window.webkitRequestAnimationFrame ||
        window.mozRequestAnimationFrame ||
        window.oRequestAnimationFrame ||
        window.msRequestAnimationFrame ||
        function (callback) {
          window.setTimeout(callback, 1000 / 60);
        });

    }();

    // These are the valid position values for the parent of the ripple to get the ripple to display correctly
    const validStyles = ["absolute", "relative", "fixed"];

    // helper cross browser function to get data from an element
    const getData = document.body.dataset ?
      (el, data) => el.dataset[data] :
      (el, data) =>
        el.getAttribute(
          "data-" +
          data.replace(
            /([a-z])([A-Z])([^A-Z]|$)/g,
            (a, b, c, d) => b + "-" + c.toLowerCase() + (d || "")));


    // remove the function
    const removeAfterTransition = function (e) {
      this.parentNode.removeChild(this);
    };

    // Core function, adds the ripples and adds all events
    const addRipple = function (e, autoremove = true) {
      // Context:
      // this - The element we are adding the ripple to
      // e - The original event object

      // Maximum size our ripple needs to be
      // this will be multiplied by 3 incase the user clicks in the bottom corner
      // to make sure the entire element is covered
      let sizeMax = Math.max(this.offsetWidth, this.offsetHeight) + "px";
      // create our ripple, add the class
      let ripple = document.createElement("div");
      ripple.className = "ripple";
      // the correct place to put the ripple is dependant on the element position
      // and the click position on screen therefore we need to get both of these;
      let boundingRect = this.getBoundingClientRect();
      ripple.style.top = e.clientY - boundingRect.top + "px";
      ripple.style.left = e.clientX - boundingRect.left + "px";
      ripple.style.width = ripple.style.height = sizeMax;

      // if data-ripple-color exists on the element with the ripple, we need to change the ripples color
      let colorData = getData(this, "rippleColor");
      if (colorData) {
        // Using a custom made Color class to convert colors into RGBA
        let color = new Color(colorData);
        // Drop opacity down
        if (color.a >= 1) color.a = 0.2;
        ripple.style.background = color.toRGBAString();
      }
      // Add our ripple to our original element
      this.appendChild(ripple);

      // We'll also need to make sure that the parent class has the correct styles (so that the ripple appears correctly)
      // create an array of functions to revert our original element to it's old state
      let revertFunctions = [];
      if (window.getComputedStyle) {
        let computedStyle = window.getComputedStyle(this);
        // check that the computed styles are correct, if not, set them
        // and add a function to revert changes if there are no more ripples remaining on our element
        // to allow for multi-ripples
        let elPos = computedStyle.position;
        if (!validStyles.some(x => x.toLowerCase() == elPos)) {
          revertFunctions.push(
            function () {
              if (!this.querySelector(".ripple")) this.style.position = "";
            }.bind(this));

          this.style.position = "relative";
        }

        if (computedStyle.overflow.toLowerCase() != "hidden") {
          revertFunctions.push(
            function () {
              if (!this.querySelector(".ripple")) this.style.overflow = "";
            }.bind(this));

          this.style.overflow = "hidden";
        }
      }
      // wait for next frame before adding the activator class to the ripple
      window.requestAnimFrame(() => ripple.classList.add("is-active"));

      // create function to begin disposal of ripple
      let beginDisposal = function (e) {

        let rip;
        if (this && this.classList && this.classList.contains('ripple') && this != window)
          rip = this;
        else

          rip = ripple;
        rip.classList.add("is-dying");
        rip.addEventListener("transitionend", function (e) {
          // if the transition that ended was the opacity transition
          if (e.propertyName.match(/opacity/i) && this.parentNode) {
            this.parentNode.removeChild(this);
            // revert state back to original (can be optimised if we use a normal for loop
            revertFunctions.forEach(x => x());
          }
        });
        // remove the events afterwards (cleanup)
        let parent = this.parentNode;
        parent.removeEventListener("mouseup", beginDisposal);
        parent.removeEventListener("mouseleave", beginDisposal);
        parent.removeEventListener("touchend", beginDisposal);
      };

      // add event to element

      ripple.remove = beginDisposal;
      if (autoremove) {
        window.addEventListener("mouseup", beginDisposal);
        this.addEventListener("mouseleave", beginDisposal);
        window.addEventListener("mouseleave", beginDisposal);
        this.addEventListener("touchend", beginDisposal);
      }
      return ripple;
    };

    // Recursively find parent elements until we find one that has class class that allows for ripples
    const elementWithClass = (el, regex) => {
      if (el.className && el.className.match(regex)) return el;
      return el.parentNode && elementWithClass(el.parentNode, regex);
    };

    // Event listener, when the body is clicked, it will search up the events target
    // for the correct class, if one exists, we add a ripple to it. By doing it this way,
    // we can automatically include any new elements that are added (including ones added by packages like)
    // Vue, React, Angular.js etc.
    const trigger = function (e) {
      let el = elementWithClass(e.target, /(?:js\-hasRipple|btn\-ripple)/);
      if (el && !el.className.match(/btn\-\-disabled/) && !el.disabled) {
        addRipple.call(el, e);
      }
    };

    return {
      enable: function () {
        document.body.addEventListener("mousedown", trigger);
        document.body.addEventListener("touchstart", trigger);
      },
      disable: function () {
        document.body.removeEventListener("mousedown", trigger);
      },
      createRipple(el, e, remove = true) {
        return addRipple.call(el, e, remove);
      }
    };

  }();

  Ripple.enable();


  let options = document.querySelectorAll('.radiolabel');
  let radios = document.querySelectorAll('.card-radio');
  let ripples = [];
  let choice = -1;

  let optsFunc = function (e) {
    ripples.forEach(x => x.remove());
    ripples = [];
    ripples.push(Ripple.createRipple(this, e, false));

  };

  options.forEach(x => x.addEventListener('mousedown', optsFunc));

  /*
    Material tabs
  */

  $('#material-tabs').each(function () {
    var $active, $content, $links = $(this).find('a');

    $active = $($links[0]);
    $active.addClass('active');

    $content = $($active[0].hash);

    $links.not($active).each(function () {
      $(this.hash).hide();
    });

    $(this).on('click', 'a:not(#action)', function (e) {

      $active.removeClass('active');
      $content.hide();

      $active = $(this);
      $content = $(this.hash);

      $active.addClass('active');
      $content.show();

      e.preventDefault();
    });
  });

  /*
    material-style dropdown
  */


  $(document).on('click', '.gtaw-dropdown', function () {
    var $button = $(this);
    var target = $(this).attr('action-target');
    if ($(target).is('.active')) {
      $(target).removeClass('active');
    } else {
      $(target).addClass('active');
    }
  });

  $(document).on('mouseup', function (e) {
    var element = $('.gtaw-select-dropdown');
    if (!element.is(e.target) && element.has(e.target).length === 0) {
      element.removeClass('active');
      $('button[action-target="#' + element.attr('id') + '"]').show();
    }
  });

  (function (old) {
    $.fn.attr = function () {
      if (arguments.length === 0) {
        if (this.length === 0) {
          return null;
        }

        var obj = {};
        $.each(this[0].attributes, function () {
          if (this.specified) {
            obj[this.name] = this.value;
          }
        });
        return obj;
      }

      return old.apply(this, arguments);
    };
  })($.fn.attr);

  $('.gtaw-select-dropdown').data('selectedValue', $('.gtaw-select-dropdown .gtaw-select-dropdown-item:first-child').attr());

  $(document).on('click', '.gtaw-select-dropdown .gtaw-select-dropdown-item', function () {
    let dropdown = $(this).parent();
    let attributes = $(this).attr();
    let dropdownId = dropdown.attr('id');
    let value = $(this).html();
    dropdown.data('selectedValue', attributes);
    $(this).parents('.gtaw-select-dropdown').removeClass('active');
    if ($('.gtaw-dropdown[action-target="#' + dropdownId + '"]').is('.gtaw-dropdown-select-dependable')) {
      $('.gtaw-dropdown[action-target="#' + dropdownId + '"]').html(value.toUpperCase() + ' <i class="fas fa-chevron-down"></i>');
      $('.gtaw-dropdown[action-target="#' + dropdownId + '"]').attr('selection-value', value);
    }
  });

  $(document).on('click', '.gtaw-select-dropdown .gtaw-select-dropdown-group', function () {
    var $button = $(this);
    //$button.parent().removeClass('active');
    var target = $button.children('.gtaw-select-dropdown-group-items');
    if ($(target).is('.active')) {
      $(target).removeClass('active');
      $button.removeClass('active');
    } else {
      $(target).addClass('active');
      $button.addClass('active');
    }
  });


  $(document).on('click', '.gtaw-radio', function () {
    var checkboxgroup = "input:checkbox[name='" + $(this).attr("name") + "']";
    $(checkboxgroup).prop("checked", false);
    $(this).prop("checked", true);
  });

  $('.banner__cross').on('click', function () {
    $(this).parent().slideUp();
    Cookies.set('bf_banner', 'hide', { expires: 14, domain: 'gta.world' })
  });

  if (Cookies.get('bf_banner') == 'hide') {
    $('.banner').hide();
  }

  $(document).on('click', '.expansion-panel', function(e) {
    let $panel = $(this);
    let $content = $panel.children('.expansion-panel-content')[0];
    let $group = $panel.parents()[0];
    let isActive = $panel.hasClass('active');
    const isExpPanelContentChild = e.target.matches('.expansion-panel-content, .expansion-panel-content *');

    if (!isExpPanelContentChild) {
      $($group).children('.expansion-panel').removeClass('active');
      $($group).children('.expansion-panel').children('.expansion-panel-content').removeClass('active');
      if (isActive) {
        $panel.removeClass('active');
        $($content).removeClass('active');
      } else {
        $panel.addClass('active');
        $($content).addClass('active');
      }
    }
  });

});

function loadingSpinner(size = 1, border = 1, center = 1) {
  let domElement = $('<div class="loader">\
    <svg class="circular" viewBox="25 25 50 50">\
    <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="2" stroke-miterlimit="10"/>\
    </svg>\
</div>');

  if (size > 1) {
    domElement.children('svg').css('width', size + 'px');
    domElement.children('svg').css('height', size + 'px');
  }

  if (center) {
    domElement.addClass('text-center');
  }

  return domElement;
}
